<?php

namespace App\http\Controllers;

use App\Models\Produto;
use Illuminate\Http\Request;

class ProdutoController extends Controller
{
    public function listar(){
        $query = Produto::query();
        $produtos = $query->get();
        return view('listar', compact('produtos'));
    }

    public function add(Request $request){

        $request->validate([
            'nome' => 'required|string|max:255',
            'valor' => 'required|string|max:255|unique:produtos,valor',
            'quantidade' => 'required|string|max:255'
        ]);

        Produto::create([
            'nome' => $request->nome,
            'valor' => $request->valor,
            'quantidade' => $request->quantidade,
        ]);

        return redirect()->back()->with('sucess', 'Produto cadastrado com sucesso');
    
    }

    public function atualizar($id){
        $produto = Produto::findOrFail($id);
        return view('atualizar', copmpact('produto'));
    }   


    public function update(Request $request, $id){
        $request->validate([
            'nome' =>'required|string|max:255',
            'valor' => "required|string|max:255|unique:, valor, $id",
            'quantidade' => 'required|string|max255'
        ]);

        $produto = Produto::findOrFail($id);

        $produto->nome = $request->nome;
        $produto->valor = $request->valor;
        $produto->quantidade = $request->quantidade;
        $produto->save();
        return redirect()->back()->with('sucess', 'Produto atualizado com sucesso');

    }
}